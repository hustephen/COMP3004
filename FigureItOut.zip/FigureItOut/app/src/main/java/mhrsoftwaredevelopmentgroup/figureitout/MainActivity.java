package mhrsoftwaredevelopmentgroup.figureitout;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.transition.TransitionInflater;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.LinearInterpolator;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setSharedElementExitTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transition));
        getWindow().setSharedElementEnterTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transition));

        setContentView(R.layout.activity_main);

        final Button startButton = (Button)findViewById(R.id.startButton);
        final RelativeLayout layout = (RelativeLayout)findViewById(R.id.layout);
        final Random ran = new Random();

        startButton.setTransformationMethod(null);

        int[] androidColors = getResources().getIntArray(R.array.androidcolors);
        int randomAndroidColor = androidColors[ran.nextInt(androidColors.length)];
        layout.setBackgroundColor(randomAndroidColor);

        startButton.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) startButton.getLayoutParams();
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            lp.width = 580;
                            lp.height = 180;
                            startButton.setLayoutParams(lp);
                        }
                        if (event.getAction() == MotionEvent.ACTION_UP) {
                            lp.width = 600;
                            lp.height = 200;
                            startButton.setLayoutParams(lp);
                            startButtonClick(v);
                        }
                        return false;
                    }
                }
        );

        ObjectAnimator rot = ObjectAnimator.ofFloat((View)findViewById(R.id.imageView2), "rotation", 0f, 360f);
        rot.setDuration(3000);
        rot.setRepeatCount(ObjectAnimator.INFINITE);
        rot.setInterpolator(new LinearInterpolator());
        rot.start();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void startButtonClick(View view) {
        ActivityOptionsCompat optionsCompat=ActivityOptionsCompat.makeSceneTransitionAnimation(MainActivity.this,findViewById(R.id.imageView2),"wheel");
        Intent intent = new Intent(MainActivity.this, ChoicesActivity.class);
        startActivity(intent, optionsCompat.toBundle());
    }
}
