package mhrsoftwaredevelopmentgroup.figureitout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Random;

public class DisplayActivity extends MainActivity {

    TextView showChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        RelativeLayout layout = (RelativeLayout)findViewById(R.id.layout);

        final Random ran = new Random();
        int[] androidColors = getResources().getIntArray(R.array.androidcolors);
        int randomAndroidColor = androidColors[ran.nextInt(androidColors.length)];
        layout.setBackgroundColor(randomAndroidColor);

        showChoice = (TextView)findViewById(R.id.textView);
        String choice = getIntent().getStringExtra("choice");
        showChoice.setText(choice);

        final Button backButton = (Button)findViewById(R.id.back_button);

        backButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(DisplayActivity.this, ChoicesActivity.class);
                        startActivity(intent);
                    }
                }
        );

        backButton.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) backButton.getLayoutParams();
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            lp.width = 580;
                            lp.height = 180;
                            backButton.setLayoutParams(lp);
                        }
                        if (event.getAction() == MotionEvent.ACTION_UP) {
                            lp.width = 600;
                            lp.height = 200;
                            backButton.setLayoutParams(lp);
                        }
                        return false;
                    }
                }
        );

    }
}
