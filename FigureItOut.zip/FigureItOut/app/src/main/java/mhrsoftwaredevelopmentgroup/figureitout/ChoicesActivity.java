package mhrsoftwaredevelopmentgroup.figureitout;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.TransitionInflater;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.Random;

public class ChoicesActivity extends MainActivity {

    EditText choiceField;
    Button doneBut;
    Button nextBut;
    String choice;
    RelativeLayout layout;
    ArrayList<String> choices = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setSharedElementEnterTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transition));
        getWindow().setSharedElementExitTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transition));

        setContentView(R.layout.activity_choices);

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(choiceField, InputMethodManager.SHOW_IMPLICIT);
            }
        }, 6000);

        doneBut = (Button)findViewById(R.id.doneBut);
        nextBut = (Button)findViewById(R.id.nextBut);
        choiceField = (EditText)findViewById(R.id.choices);
        layout = (RelativeLayout)findViewById(R.id.layout);

        final Random ran = new Random();

        int[] androidColors = getResources().getIntArray(R.array.androidcolors);
        int randomAndroidColor = androidColors[ran.nextInt(androidColors.length)];
        layout.setBackgroundColor(randomAndroidColor);

        choiceField.setOnKeyListener(
                new View.OnKeyListener() {
                    @Override
                    public boolean onKey(View v, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_ENTER) {
                            choices.add(choiceField.getText().toString());
                            choiceField.setText("");
                        }
                        return false;
                    }
                }
        );
        choiceField.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        choiceField.setText("");
                    }
                }
        );

        doneBut.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (choices.size() != 0) {
                            int num = ran.nextInt(choices.size());
                            choice = choices.get(num);

                            Intent intent = new Intent(ChoicesActivity.this, DisplayActivity.class);
                            intent.putExtra("choice", choice);
                            startActivity(intent);
                        }
                    }
                }
        );

        doneBut.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        RelativeLayout.LayoutParams lp = (RelativeLayout.LayoutParams) doneBut.getLayoutParams();
                        if (event.getAction() == MotionEvent.ACTION_DOWN) {
                            lp.width = 580;
                            lp.height = 580;
                            doneBut.setLayoutParams(lp);
                        }
                        if (event.getAction() == MotionEvent.ACTION_UP) {
                            lp.width = 600;
                            lp.height = 600;
                            doneBut.setLayoutParams(lp);
                        }
                        return false;
                    }
                }
        );

        nextBut.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        choices.add(choiceField.getText().toString());
                        choiceField.setText("");
                    }
                }
        );

    }
}

