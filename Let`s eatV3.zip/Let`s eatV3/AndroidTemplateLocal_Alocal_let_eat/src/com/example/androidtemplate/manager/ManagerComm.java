package com.example.androidtemplate.manager;


import com.nostra13.universalimageloader.core.DisplayImageOptions;

/**
 * 静态变量管理
 */
public class ManagerComm {

	public static DisplayImageOptions displayImageOptions;

}
