package mhrsoftwaredevelopmentgroup.letseat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

/**
 * Created by Jason on 2017-10-31.
 */
public class InformationActivity extends AppCompatActivity {

    Double lon;
    Double lat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information);
        String result = getIntent().getExtras().getString("result");

        String parts[] = result.split("\\/");
        String name = parts[0];
        lat = Double.parseDouble(parts[1]);
        lon = Double.parseDouble(parts[2]);
        TextView nameField = (TextView)findViewById(R.id.editText);
        nameField.setText(name);
    }

    public void onClick(View view){
        String geoUri = "http://maps.google.com/maps?q=loc:" + lat + "," + lon;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
        startActivity(intent);
    }
}
